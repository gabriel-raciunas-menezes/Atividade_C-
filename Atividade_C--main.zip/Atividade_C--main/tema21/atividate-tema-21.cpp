#include <stdio.h>
#include <fstream>
#include <iostream>
#include <sstream>
using namespace std;

#include <list>


struct RegistroEscolar{
    unsigned int ano;
    string turma;
    string horario;
    string materias;
    unsigned int n_alunos;
    string professor_responsavel;
};


class keyValuePair{
    private:
        string __key;
        string __str_value;
        unsigned int unsigned_int_value;
        unsigned int currType = UNDEFINED;
    public:
        const unsigned int static UNDEFINED = 0;
        const unsigned int static TYPE_UNSIGNED_INT = 1;
        const unsigned int static TYPE_STR = 2;
        const unsigned int static TYPE_INT = 3;

        keyValuePair(string key, string value) : __key(key), __str_value(value), currType(TYPE_STR){}
        keyValuePair(string key, unsigned int value) : __key(key), unsigned_int_value(value), currType(TYPE_UNSIGNED_INT){}
        keyValuePair(string key) : __key(key){}


        unsigned int unsigned_intget(){return unsigned_int_value;}
        string strget(){return __str_value;}
        string getkey(){return __key;}

        bool unsigned_intset(unsigned int data){
            if(currType != TYPE_UNSIGNED_INT) return false;
            unsigned_int_value = data;
            return true;
        }

        bool strset(string data){
            if(currType != TYPE_STR) return false;
            __str_value = data;
            return true;
        }

        unsigned int typeofValue(){return currType;}
        unsigned int loadFromString(string &input, bool set = true){
            try{
                size_t pos;
                int res = stoi(input, &pos);
                if(pos != input.length() || res> UINT_MAX) {
                    if(set) __str_value = input;
                    return TYPE_STR;
                }
                if(res <0) return TYPE_INT;
                if(set) unsigned_int_value = res;
                return TYPE_UNSIGNED_INT;
            }catch(const exception&){
                return UNDEFINED;
            }
        }

        string serialize(){
            switch(currType){
                    case keyValuePair::TYPE_INT: 
                    case keyValuePair::UNDEFINED : 
                        return "";
                    case keyValuePair::TYPE_UNSIGNED_INT: 
                        return strget();
                    case keyValuePair::TYPE_STR: 
                        return to_string(unsigned_intget());
                }
            throw runtime_error("Unknown type");
        }
};

class Tabela{
    private:
        fstream* __fptr;
        list<keyValuePair> datas;
        bool dataLoaded = false;
        char separator;
        string filePath;

        bool read(){
            if(dataLoaded) return true;
            if(__fptr->is_open()) __fptr->close();

            __fptr->clear();
            __fptr->open(filePath, ios::in);

            if(!__fptr->is_open()) return false;
            cout << "Reading file " << fileName << endl;

            list<keyValuePair> bufferList;
            string buffer;

            while(getline(*__fptr, buffer)){
                try{
                    bufferList.push_back(parseLine(buffer));
                }catch(const exception& e){
                    cout << "Error: " << e.what() << endl;
                    __fptr->close();
                    return false;
                }
            }

            const bool ferr = __fptr->bad();
            __fptr->close();
            if(bufferList.empty() || ferr) return false;
            
            datas = move(bufferList);
            dataLoaded = true;
            return true;
        }

        keyValuePair* parseLine(string const &input){
            string key;
            string value;
            istringstream inputStream(input);

            if(!getline(inputStream, key, separator) || !getline(inputStream, value)) throw invalid_argument("line parsed don't have key or value");

            keyValuePair pair = new keyValuePair(key);
            pair.loadFromString(value);

            return pair;
        }

        string getColumnName(const unsigned int &colunaId){
            switch (colunaId)
            {
                case turma:
                    columnName = "turma";
                    break;
                case ano:
                    columnName = "ano";
                    break;
                case horario:
                    columnName = "horario";
                    break;
                case materias:
                    columnName = "materias";
                    break;
                case n_alunos:
                    columnName = "n_alunos";
                    break;
                case professor_responsavel:
                    columnName = "professor_responsavel"; 
                    break;       
                default:
                    throw invalid_argument("parameter colunaId not found! must be one of constant defined in Tabela::const");
            }
            return columnName;
        }

        string dataFormat(const unsigned int &colunaId, const string &data){
            string columnName = getColumnName(colunaId);
            return columnName + separator + data;
        }

        string dataFormat(const string &columnName, const string &data){
            return columnName + separator + data;
        }

    public:
        const static unsigned int turma = 1;
        const static unsigned int ano = 2;
        const static unsigned int horario = 3;
        const static unsigned int materias = 4;
        const static unsigned int n_alunos = 5;
        const static unsigned int professor_responsavel = 6;

        Tabela(const string &fileName, const char separator, const string &currDir) :
        separator(separator), filePath(currDir + fileName), __fptr(new fstream())
        {
            __fptr->open(currDir + fileName);
            
            if(!fptr->is_open()) {
                string errorMsg = "failed to open or create file: ";
                delete __fptr;
                __fptr = nulptr;
                throw std::runtime_error(errorMsg + currDir + fileName);
            }
            fptr->close();

            __fptr = move(fptr);
        }
        ~Tabela(){
            if(__fptr != nullptr){
                if(__fptr->is_open())__fptr->close();
                delete __fptr;
                __fptr = nullptr;
            }

        }

        void end(){
            __fptr->close();
        }

        void insert(const unsigned int &colunaId, const string &data){
            __fptr->open(filePath, ios::out|ios::app);
            if(!__fptr->is_open()) {
                string errorMsg = "failed to open or create file: ";
                __fptr->close();
                throw std::runtime_error(errorMsg + filePath);
            }

            *__fptr << dataFormat(colunaId,data);
            __fptr->close();
        }

        bool modificarDados(const unsigned int &colunaId, string dados){
            if(!dataLoaded && !read()) {
                cout << "failed to modify data!" << endl;
                return false;
            }

            try{
                keyValuePair &targetData = (*this)[colunaId];
                targetData.loadFromString(dados);
            }catch(const exception &e){
                cout << "ERROR while modifying data: "<< e.what();
                return false;
            }
            return true;
        }


        keyValuePair &operator[](const string &columnName){
            for(auto &pair: datas){
                currKey = pair.getkey();
                if(currKey==columnName) return pair;
            }

            throw out_of_range("Column not found!");
        }

        keyValuePair &operator[](const unsigned int &colunaId){
            return (*this)[getColumnName(colunaId)];
        }

        void commit(){
            if(!dataLoaded || datas.empty()) {
                cout << "iNFO: No data to commit...";
                return;
            }

            if(__fptr->is_open()) __fptr->close();
            __fptr->open(filePath,ios::out | ios::trunc);

            if(!__fptr->is_open()){
                cout << "ERROR: cannot open file -[" << filePath << "]" << endl;
                return;
            }

            for(auto it : datas){
                string key = it.getkey();
                string value = it.serialize();
                
                __fptr << dataFormat(key, value);
                cout << "INFO: Inserted new data! [key:\"\"" << key << " | value:"<< value << "]";
            }
            __fptr->close();
        }
};

int main(){
    return 0;
}